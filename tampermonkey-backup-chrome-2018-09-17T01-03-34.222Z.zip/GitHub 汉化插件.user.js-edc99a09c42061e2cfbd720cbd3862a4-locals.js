var I18N = {};

I18N.conf = {
    /**
     * ��фubc
     */
    rePageClass: /\b(vis-public|page-(dashboard|profile|account|new-repo|create-org)|homepage|signup|session-authentication|oauth)\b/,

    /**
     * 9M pathname ub�c
     *
     * �ub /notifications
     * s�ub /watching
     * �^ub /stars
     * �ub /issues
     * ���B /pulls
     * "ub /search
     * ��ub /trending
     * U:ub /showcases
     * �eӓ /new/import
     *
     * *{U�u /
     */
    rePagePath: /\/(notifications|watching|stars|issues|search|pulls|trending|showcases|$|new\/import)/,

    /**
     * 9M url ub�c
     *
     * �G�ub gist
     */
    rePageUrl: /(gist)\.github.com/,

    /**
     * �e:߄ class c
     *
     * bQ breadcrumb
     * ��h files js-navigation-container js-active-navigation-container
     * �خ highlight tab-size js-file-line-container
     * �� data highlight blob-wrapper
     * wiki�� markdown-body
     */
    reIgnore: /(breadcrumb|files js-navigation-container|highlight tab-size|highlight blob-wrapper|markdown-body)/,
};

I18N.zh = {
    "title": { // ���
        "static": { // Y��
        },
        "regexp": [ // c��
        ],
    },

    "pubilc": { // lq:���
        "static": { // Y��
            // *{U�
            "Personal": "*�",
            "Open source": " �",
            "Business": "F",
            "Pricing": "��",
            "Support": "/",
            "Sign in": "{U",
            "Sign up": "�",

            "Search GitHub": "GitHub  `1�S",
            "This repository": "SMӓ",
            "Search": """,

            "Pull Requests": "���B",
            "Pull requests": "���B",
            "Issues": "�",
            "Marketplace": ":",
            "Gist": "�G�",
            "Your dashboard": "�ޖu",

            "You have no unread notifications": "��	*��",
            "You have unread notifications": "�	*��",
            "Create new&": "��&",
            "View profile and more": "���o",

            "New repository": "��ӓ",
            "New organization": "����",
            "Import repository": "�eӓ",
            "New gist": "���G�",
            "New issue": "���",

            "Signed in as": "�}",
            "Your profile": "��;u",
            "Your stars": "�^�y�",
            "Your gists": "���G�",
            "Explore": "�"",
            "Integrations": "�",
            "Help": ".�",
            "Settings": "�n",
            "Sign out": " �",

            "Showcases": "U�",
            "Trending": "��",
            "Stars": "�^",


            "Previous": "
 u",
            "Next": " u",

            "Period:": " �:",
            "Filter activity": "	���",
            "1 day": " )",
            "3 days": "	)",
            "1 week": " h",
            "1 month": " *",

            "Confirm password to continue": "n��M����\",
            "Password": "�",
            "(Forgot password)": "(ذ�)",
            "Confirm password": "��",

            "Updated": "��",
            "Terms": "a>",
            "Privacy": "��",
            "Security": "�h",
            "Contact": "T�",
            "Status": "�",
            "Training": "��",
            "Shop": "F�",
            "Blog": "Z�",
            "About": "s�",

            // ĺ�h��
            "Write": "�",
            "Preview": "��",

            "Add header text": "�",
            "Add bold text <cmd+b>": "�� <cmd+b>",
            "Add italic text <cmd+i>": "�S <cmd+i>",
            "Insert a quote": "�e(",
            "Insert code": "�e�",
            "Add a link <cmd+k>": "ޥ <cmd+k>",
            "Add a bulleted list": "����h",
            "Add a numbered list": "��	�h",
            "Add a task list": "����h",
            "Directly mention a user or team": "���0(7�",
            "Reference an issue or pull request": "�����B",
            "Leave a comment": "Yĺ",

            "Attach files by dragging & dropping,": "����D�",
            "selecting them": "	��",
            ", or pasting from the clipboard.": "6�4��",
            "Styling with Markdown is supported": "/ Markdown ���",

            "Close issue": "s��",
            "Comment": "Ф",
            "Submit new issue": "Ф��",
            "Comment on this commit": "Ф",
            "Close and comment": "Фvs�",
            "Reopen and comment": "ФvͰS ",
            "Reopen issue": "ͰS �",

            // lq�\�
            "Followers": "�",
            "Follow": "s�",
            "Unfollow": "ֈs�",
            "Watch": "s�",
            "Unwatch": "ֈs�",
            "Star": "�^",
            "Unstar": "ֈ�^",
            "Fork": ">",

            // �����:
            "Please verify your email address to access all of GitHub's features.": "�����5P��0@� /@	 GitHub ��",
            "Configure email settings": "�95P���n",
            "Your email was verified.": "����0@���",
        },
        "regexp": [ // c�� (lq:�c�!(��:�%e��фŵ)
            /**
             * 9M��<
             *
             * Mar 19, 2015  Mar 19, 2016
             * January 26  March 19
             * March 26
             *
             * �S/&3�, ��H�(@. 2016-03-19 20:46:45
             */
            [/(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May(?:)?|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?) (\d+)(?:, (\d+)|)/g, function (all, month, date, year) {
                var monthKey = {
                    "Jan": "1",
                    "Feb": "2",
                    "Mar": "3",
                    "Apr": "4",
                    "May": "5",
                    "Jun": "6",
                    "Jul": "7",
                    "Aug": "8",
                    "Sep": "9",
                    "Oct": "10",
                    "Nov": "11",
                    "Dec": "12"
                };
                return (year ? year + 't' : '') + monthKey[month.substring(0, 3)] + date + '�';
            }],
            /**
             * ����<
             */
            [/just now|(an?|\d+) (second|minute|hour|day|month|year)s? ago/, function (m, d, t) {
                if (m === 'just now') {
                    return '';
                }

                if (d[0] === 'a') {
                    d = '1';
                } // a, an �9: 1

                var dt = {second: '�', minute: '�', hour: '�', day: ')', month: '*', year: 't'};

                return d + ' ' + dt[t] + 'KM';
            }],

            // ӓ d�:
            [/Your repository "([^"]+)"was successfully deleted\./, "�� \"$1\"ӓ�� d"],
            // �����:
            [/An email containing verification instructions was sent to (.+)\./, "������0 $1"],
            // 4�b���o
            [/Joined on/, "茎"],
        ],
    },

    "page-dashboard": { // �{U��u
        "static": { // Y��
            // �K.�
            "Learn Git and GitHub without any code!": "�� Git � GitHub � �U�",
            "Using the Hello World guide, youll create a repository, start a branch,": "( Hello World W�� *ӓ � */",
            "write comments, and open a pull request.": "�ĺv� *���B(Y��1�ц...)",
            "Let's get started!": "�� �'",
            "Hide this notice forever": "8E�����o",

            "Welcome to GitHub! Whats next?": ""�e0 GitHub er�H",
            "Create a repository": "� *ӓ",
            "Tell us about yourself": "�� `��",
            "Browse interesting repositories": "O�	�D��",
            "on Twitter": "( Twitter 
",

            "You dont have any repositories yet!": "��Mء	�Uӓ",
            "Create your first repository": "���, *ӓ",
            "or": "",
            "learn more about Git and GitHub": "f`�s� Git � GitHub ��",

            // �	ӓ�y�
            "Repositories you contribute to": "�!.Ǆӓ",
            "Your repositories": "��ӓ",
            "Find a repository&": ""ӓ&",
            "All": "h�",
            "Public": "lq",
            "Private": "�	",
            "Sources": "�",
            "Forks": ">",

            "View": "�",
            "new broadcast": "a�lJ",
            "new broadcasts": "a�lJ",

            // � ��
            "starred": "^�",
            "forked": ">�",
            "forked from": ">�",
            "created repository": "��ӓ",
            "opened pull request": "�w����B",
            "commented on pull request": "ĺ����B",
            "opened issue": "���",
            "close issue": "s��",
            "added": "���",
            "to": "0",
            "pushed to": "��",
            "closed issue": "s��",
            "merged pull request": "v����B",
            "commented on issue": "Ф�ĺ",

            "More": "�",


            "Switch dashboard context": "bؤ��",
            "Manage organizations": "���",
            "Create organization": "���",

            // �!�e���
            "Youve been added to the": "��ϫ��0",
            "organization!": "��",
            "Here are some quick tips for a first-time organization member.": "�/�!�e�Ǆ ��:",
            "Use the switch context button in the upper left corner of this page to switch between your personal context (": "(ub�
҄b��	����((",
            ") and organizations you are a member of.": ")��ǫ�K��Lb",
            "After you switch contexts youll see an organization-focused dashboard that lists out organization repositories and activities.": "S�b���0 *��:-Äubv-���Ǔ�;�",
        },
        "regexp": [ // c��
            [/Show (\d+) more repositories&/, ">: $1 *��ӓ&"],
        ],
    },

    "page-profile": { // *��u
        "static": { // Y��
            "Updating your profile with your name, location, and a profile picture helps other GitHub users get to know you.": "����D��o��0@4�ID��v�(7�����",

            "Joined on": "茎",
            "Change your avatar": "�94�",
            "Starred": "^�",
            "Following": "s�",
            "Organizations": "��",
            "Contributions": "!.",
            "Public contributions": "!.",
            "Overview": "��",
            "Repositories": "ӓ",
            "Public activity": "�",
            "Edit profile": "�9�n",
            "Popular repositories": "AL�ӓ",
            "Pinned repositories": "���ӓ",
            "Customize your pinned repositories": "�I����ӓ",
            "Repositories contributed to": "!.Ǆӓ",
            "Contribution activity": "!.�o",

            "You can now pin up to 6 repositories.": "`�(��n6*��ӓ",
            "Select up to five public repositories you'd like to show.": " �	�*�>:�lqӓ",
            "Show:": ">::",
            "Your repositories": "��ӓ",
            "Repositories you contribute to": "�!.Ǆӓ",
            "Save pinned repositories": "�X��ӓ",

            "Jan": "1",
            "Feb": "2",
            "Mar": "3",
            "Apr": "4",
            "May": "5",
            "Jun": "6",
            "Jul": "7",
            "Aug": "8",
            "Sep": "9",
            "Oct": "10",
            "Nov": "11",
            "Dec": "12",

            "January": " ",
            "February": "�",
            "March": "	",
            "April": "�",
            "May": "�",
            "June": "m",
            "July": "",
            "August": "k",
            "September": "]",
            "October": "A",
            "November": "A ",
            "December": "A�",

            "Mon": "h ",
            "Wed": "h	",
            "Fri": "h�",

            "Includes contributions from private repositories you can access.": "�������ӓ",
            "Summary of pull requests, issues opened, and commits.": "� ���B, ��, Ф.",
            "Learn how we count contributions": "���S�U��!.�",
            "Less": "",
            "More": "",

            // "Contributions in the last year": "ǻ t�!.",
            // "Longest streak": " ��!.)p",
            // "Current streak": "SM��!.)p",
            // "No recent contributions": " ѡ	!.",

            // 2016-05-20 ��!.��
            "Contribution settings": "!.�n",
            "Select which contributions to show": "	�>:��!.",
            "Public contributions only": "�lq�!.",
            "Visitors to your profile will only see your contributions to public repositories.": "��0��*�D��0lqӓ��!.",
            "Public and private contributions": "lq���!.",
            "Visitors to your profile will see your public and anonymized private contributions.": "��0��*�D�0��lq�?���!.",
            "Visitors will now see only your public contributions.": "���0�lqӓ��!.",
            "Visitors will now see your public and anonymized private contributions.": "��0��lq�?���!.",

            "commits": "!Ф",
            "Pull Request": "���B",
            "Pull Requests": "���B",
            "Issue reported": "J",
            "Issues reported": "J",

            // � ��
            "starred": "^�",
            "forked": "6φ",
            "forked from": "6��",
            "created repository": "��ӓ",
            "opened pull request": "�w����B",
            "commented on pull request": "ĺ����B",
            "opened issue": "���",
            "close issue": "s��",
            "added": "���",
            "to": "0",
            "pushed to": "��",
            "closed issue": "s��",
            "merged pull request": "v����B",
            "commented on issue": "Ф�ĺ",

            // ӓ tab
            "Find a repository&": ""ӓ&",
            "All": "h�",
            "Public": "lq",
            "Private": "�	",
            "Sources": "�",
            "Forks": ">",
            "Mirrors": "\�",
            "New": "��",

            "Block or report": ";b>�",
            "Learn more about blocking a user.": "��Ƅ;b(7�o",
            "Block or report this user": ";b>��(7",
            "Block user": ";b�(7",
            "Hide content and notifications from this user.": "O=@	e��(7��o",
            "Report abuse": ">��(7",
            "Contact Support about this user's behavior.": "�(7L:
�",

            "Search repositories&": ""ٛ�&",
            "Search starred repositories&": ""�^�ӓ&",
            "Type:": "{�:",
            "Select type:": "	�{�:",
            "Language:": "� :",
            "Select language:": "	�� :",
            "All languages": "@	� ",

            "Sort:": "��:",
            "Sort options": "��	y",
            "Recently starred": " �s�",
            "Recently active": " �;��",
            "Most stars": " ^�",
            "Unstar": "ֈ�^",

            "Jump to": "�l0",
            "First pull request": ", !���B",
            "First issue": ", !��",
            "First repository": ", *ӓ",
            "Joined GitHub": "� GitHub",
            "Show more activity": ">:�",
        },
        "regexp": [ // c��
            [/Created (\d+)[\s\r\n]+commits? in[\s\r\n]+(\d+)[\s\r\n]+repositor(y|ies)/, "( $2 *�-�� $1 !Ф"],
            [/Created (\d+)[\s\r\n]+repositor(y|ies)/, "�� $1 *ӓ"],
            [/Opened (\d+)[\s\r\n]+other[\s\r\n]+pull requests?/, "�w� $1 *���B"],
            [/Opened (\d+)[\s\r\n]+other[\s\r\n]+issues/, " � $1 *v��"],
            [/(\d+) commits?/, "$1 !Ф"],
            [/Pushed (\d+) commits? to/, "�� $1 !Ф0"],
            [/Follow ([^]+)s activity feed/, "s� $1 � feed"],
            [/([^ ]+) has no activity during this period\./, "$1 ��	�U;�"],
            [/([\s\S]+?) has no activity yet for this period\./, "$1 ��	�U;�"],
            [/(\d+) total/, "$1 !"],
            [/(\d+) days?/, "$1 )"],
            [/([\d,]+) contributions in the last year/, "$1 !!.(ǻ� t-"],
        ],
    },

    "page-account": { // *��n
        "static": { // Y��
            // �U
            "Personal settings": "*��n",
            "Profile": "�,�o",
            "Account": "7�n",
            "Emails": "���n",
            "Notifications": "�n",
            "Billing": ""��o",
            "SSH and GPG keys": "SSH � GPG keys",
            "Security": "�h�o",
            "OAuth applications": "�C�(",
            "Personal access tokens": "���L",
            "Repositories": "ӓ�",
            "Organizations": "�ǡ",
            "Saved replies": "�w�",

            // Profile �U
            "Public profile": "�,D�",
            "Profile picture": "�4�",
            "Upload new picture": "
 ��G",
            "You can also drag and drop a picture from your computer.": "�_������gG\�
 .",
            "Name": "5�",
            "Public email": "lq��",
            "Dont show my email address": ">:���",
            "You can add or remove verified email addresses in your": "����� d��0@(��",
            "personal email settings": "���n",
            "URL": "Q�",
            "Company": "l�",
            "You can": "���",
            "other users and organizations to link to them.": "v�(7�����0��",
            "Location": "0@",
            "your company's GitHub organization to link it.": "5l��GitHub���T�we",
            "Update profile": "��D�",
            "Profile updated successfully": "D����",

            "Contributions": "!.",
            "Include private contributions on my profile": "(�;u>:��!.",
            "Get credit for all your work by showing the number of contributions to private repositories on your profile without any repository or organization information.": ">:@	���ӓ�!.0��*�D�ub���ӓ�o",
            "Learn how we count contributions": "��ߡ!.",
            "Update contributions": "��!.",

            "GitHub Developer Program": "GitHub  ��",
            "Building an application, service, or tool that integrates with GitHub?": "���(���w,��GitHub",
            "Join the GitHub Developer Program": "�e GitHub  ��",
            ", or read more about it at our": "����o(�",
            "Developer site": " �ٹ",

            "Jobs profile": "1�",
            "Available for hire": "BHR&p",
            "Save jobs profile": "�X�",


            // Account settings �U
            "Change password": "�9�",
            "Old password": "��",
            "New password": "���",
            "Confirm new password": "�!�e���",
            "Update password": "��",
            "I forgot my password": "ذ���",
            "Looking for two-factor authentication? You can find it in": "(�ͤ����",
            "Change username": "�9(7",
            "Changing your username can have": "�9��(7��",
            "unintended side effects": "�0�o\(",
            "Delete account": " d7",
            "Once you delete your account, there is no going back. Please be certain.": " � d�71���b�	L",
            "Delete your account": "n� d",

            // Emails �U
            "Your": "��",
            "primary GitHub email address": "GitHub Email ;7",
            "will be used for account-related notifications (e.g. account changes and billing receipts) as well as any web-based GitHub operations (e.g. edits and merges).": "�(��6�s� (��&U�o)���U�� web � GitHub �\ (���v�\)",
            "Primary": ";7",
            "Private": "�	",
            "Public": "l ",
            "This email will be used as the 'from' address for web-based GitHub operations.": "宱�(\ \"���\"0@",
            "Your primary email address is now public.": ";��0@�(/l �",
            "Your primary email address is now private.": ";��0@�(/�Ƅ",
            "Set as primary": "�:;7",
            "Add email address": "�� Email 0@",
            "Add": "��",
            "Keep my email address private": "���0@��",
            "We will use": "�(",
            "when performing web-based Git operations and sending email on your behalf. If you want command line Git operations to use your private email you must": "\:ؤ\"���\"0@娄I�5P������(}�L Git ��\-(������0@��{(",
            "set your email in Git": "Git -�n��5P��0@",
            "Email preferences": "Email O}�n",
            "Receive all emails, except those I unsubscribe from.": "�6@	��d��� ���o",
            "We'll occasionally contact you with the latest news and happenings from the GitHub Universe.": "�� GitHub Universe � ��o����٨",
            "Learn more": "��",
            "Only receive account related emails, and those I subscribe to.": "�67�s�5P��������o",
            "We'll only send you legal or administrative emails, and any emails youve specifically subscribed to.": "����ՋL?���ʨ��o",
            "Save email preferences": "�XO}",
            "Successfully updated your email preferences.": "Email O}�n�9�",
            "Looking for activity notification controls? Check the": "����Ƅ�n�M�",

            // Notification center �U
            "How you receive notifications": "�n",
            "Automatic watching": "�s�",
            "When youre given push access to a repository, automatically receive notifications for it.": "S�� *ӓ�CP�ꨥ6�s�",
            "Automatically watch repositories": "�s�ӓ",
            "Participating": "�ݘ",
            "When you participate in a conversation or someone brings you in with an": "S	�",
            "@mention": "@(7",
            "Watching": "s�ӓ",
            "Updates to any repositories or threads youre watching.": "S�s�ӓ���",
            "Your notification settings apply to the": "�n�(0",
            "repositories youre watching": "�s�ӓ",
            "Notification email": "�6儮�",
            "Primary email address": ";��0@",
            "Save": "�X",
            "Custom routing": "�I",
            "You can send notifications to different": "������",
            "verified": "��",
            "email addresses depending on the organization that owns the repository.": "5P��0@ֳ����	ӓ",

            // Billing �U
            "Billing overview": ""��o",
            "Plan": "�H",
            "Free": "M9",
            "Change plan": "�9�H",
            "per month for": "� -",
            "Learn more about Git LFS": "�H/ Git LFS ('��X�)",
            "Purchase more": "-p�",
            "Billing cycle": "ӗh",
            "Bandwidth": "&�",
            "Bandwidth quota resets every billing cycle": "&�M��*h�n",
            "Storage": "X�",
            "Payment": "/ع",
            "No payment method on file.": "�	�n/ع",
            "Add payment method": "��/ع",
            "Coupon": "�8",
            "You dont have an active coupon.": "�	�(��8",
            "Redeem a coupon": "Qb�8",
            "Payment history": "/ذU",
            "Amounts shown in USD": "�C>:",
            "You have not made any payments.": "�	/ذU",

            // Security �U
            "Two-factor authentication": "�ͤ�",
            "Status:": "�:",
            "Off": "* /",
            "Set up two-factor authentication": "�n�ͤ�",
            "provides another layer of security to your account.": ":��7Л�� B�hݜ",
            "Sessions": "��o",
            "This is a list of devices that have logged into your account. Revoke any sessions that you do not recognize.": "�/�{F���h��/�,��\��s���",
            "Your current session": "�SM��",
            "Location:": "0@",
            "Signed in:": "{F�",
            "Last accessed on": " ����",
            "Revoke": "� ",
            "Security history": "�\�U",
            "This is a security log of important events involving your account.": "�/�7��\��",

            // Applications �U
            "Authorized applications": "�C��(",
            "Developer applications": " ��(",
            "Revoke all": "� h�",
            "You have granted the following applications access to your account. Read more about connecting with third-party applications at": "��Ce�(�7�o� �����",
            "Sort": "��",
            "Sort by": "���",
            "Alphabetical": "W͒�",
            "Recently used": " �(",
            "Least recently used": " (",
            "No Developer Applications": "�� ���(",
            "Developer applications are used to access the": " ��(/(���",
            ". To get started you should": "�H���",
            "register an application": "� *�(",
            "Register new application": "茔(",
            "Register a new OAuth application": "� * OAuth �(",
            "Application name": "�(",
            "Something users will recognize and trust": "�(7�+���",
            "Homepage URL": ";u0@",
            "The full URL to your application homepage": "���(;u0@",
            "Application description": "�(��",
            "Application description is optional": "�(�� (�	)",
            "This is displayed to all potential users of your application": "٨��(7 ����o",
            "Authorization callback URL": "���0@",
            "Your applications callback URL. Read our": "���(�C�0@����",
            "OAuth documentation": "OAuth �c",
            "for more information": "",
            "Register application": "茔(",
            "Drag & drop": "��
 ",
            "or": "",
            "choose an image": "	��G",

            // Personal access tokens ub
            "Generate new token": "�����",
            "Tokens you have generated that can be used to access the": "����(e��",
            "Full control of private repositories": "�h�6�	ӓ",
            "Edit": "�",
            "Delete": " d",
            "Personal access tokens function like ordinary OAuth access tokens. They can be used instead of a password for Git over HTTPS, or can be used to": "���L��{<�OAuth������� Git Https ��",
            "authenticate to the API over Basic Authentication": "(e�LAPI(���",

            // Organizations ub
            "You are not a member of any organizations.": "����U��",
            "Transform account": "&7��",
            "Account transformation warning": "&7��fJ",
            "What you are about to do is an irreversible and destructive process. Please be aware:": "�/ *�l���n�",
            "Any user-specific information (OAuth tokens, SSH keys, Job Profile, etc) will be erased": "�U(7y���oOAuth tokens, SSH keys, Job Profile, I	� d",
            "create a new personal account": "� *��*�7",
        },
        "regexp": [ // c��
            [/This email will not be used as the 'from' address for web-based GitHub operations - we will instead use ([^@]+@users.noreply.github.com)./, "宱�(\ \"���\"0@�9( ($1) \:ؤ \"���\"0@"],
            [/Your primary email was changed to ([^@]+@[^\n]+)\./, "�� Email ;7���9: $1"],
            [/(\d+) private repositories?\./, "$1 *�	ӓ."],
            [/(\d+) data packs?/, "$1 pn"],
            [/(\d+) days? left,\n\s+billed monthly/, "$1), 	"],
            [/Using\n\s+([\d.]+) of\n\s+(\d+) GB\/month/, "$1, $2GB/"],
            [/Using\n\s+([\d.]+) of\n\s+(\d+) GB/, "$1, $2GB"],
            [/(\d+) Authorized applications?/, "$1 *�C�("],
            [/Turn (\w+) into an organization/, "�� $1 : *��"],
            [/You will no longer be able to sign into (\w+) \(all administrative privileges will be bestowed upon the owners you choose\)/, "��\:&7{U0 $1@	�CPK��	�@		"],
            [/Any commits credited to (\w+) will no longer be linked to this GitHub account/, "�UФR�� $1 ���0�* GitHub 7"],
            [/If you are using (\w+) as a personal account, you should/, "���c(( $1 \:*�7��"],
            [/before transforming (\w+) into an organization./, "(l $1 ��KM"],
        ],
    },

    "page-new-repo": { // ��ӓ
        "static": { // Y��
            "Create a new repository": "� *��ӓ",
            "A repository contains all the files for your project, including the revision history.": "ӓ+y�-�@	����U",
            "Owner": "�",
            "Repository name": "ӓ",
            "Great repository names are short and memorable. Need inspiration? How about": " *}�ӓ��/�U���O� �e�u�*WH7",
            "Description": "��",
            "(optional)": "(�	)",
            "Public": "lq (M9)",
            "Anyone can see this repository. You choose who can commit.": "�U����0�*ӓ���	��Ф",
            "Private": "�	 (69)",
            "You choose who can see and commit to this repository.": "���	����Ф0�ӓ",
            "Initialize this repository with a README": "( README.md �ӓ",
            "This will let you immediately clone the repository to your computer. Skip this step if youre importing an existing repository.": "������;K��ӓ0��5����Ф�	�ӓ��e�*	y",
            "Add .gitignore:": "�� .gitignore ��",
            "Filter ignores&": "[	�e��&",
            "Add a license:": "�����",
            "Filter licenses&": "[	��&",
            "None": "�",
            "Need help picking a license? Weve built a site just for you.": " �.�	 *���:����ub",
            "Create repository": "�ӓ",
            "Creating repository&": "�ӓ-&",
        },
        "regexp": [ // c��
        ],
    },

    "new/import": { // �eӓ
        "static": { // Y��
            // , u
            "Import your project to GitHub": "�e��y�0 GitHub",
            "Import all the files, including the revision history, from another version control system.": "�e�@	����U�� *H,�6��",
            "Your old repositorys clone URL": "`�ӓ URL 0@",
            "Learn more about the types of": "ӓ�{��.�",
            "supported VCS": "/ VCS",
            "Your new repository details": "�ӓ��",
            "Owner": "@	",
            "Name": "ӓ",
            "Your new repository will be": "�ӓ",
            "public": "l ",
            ". In order to make this repository private, youll need to": "����*ӓl:�	�` �",
            "upgrade your account": "G�7",
            "Cancel": "ֈ",
            "Begin import": " ��e",
            "Preparing import&": "��e&",
        },
        "regexp": [ // c��
        ],
    },

    "page-create-org": { // ����
        "static": { // Y��
        },
        "regexp": [ // c��
        ],
    },

    "vis-public": { // ӓu
        "static": { // Y��
            // �eӓ ,�u
            "Preparing your new repository": "���X��",
            "There is no need to keep this window open, well email you when the import is done.": "�	Ł(�*��IS�e�����5P��",
            "Detecting your projects version control system&": "�Ky�H,�6��&",
            "Importing  commits and revision history&": "�eФ���H,&",
            "Importing complete! Your new repository": "�e����ӓ",
            "is ready.": "��1�",

            // ӓub
            "Where should we fork this repository?": "���ӓ>0�*�r",

            "Code": "�",
            "Pulse": "ߡ",
            "Graphs": "�h",
            "Projects": "y�",

            // ӓ���
            "No description or website provided.": "�	Л��Q��o.",
            "Edit": "�",
            "Description": "��",
            "Short description of this repository": "������ӓ",
            "Website": "Q@",
            "Website for this repository (optional)": "�*ӓ�Q@ (�	)",
            "Save": "�X",
            "or": "",
            "Cancel": "ֈ",

            // s��n
            "Notifications": "�{�",
            "Not watching": "ֈs�",
            "Watching": "s�",
            "Ignoring": "�e",
            "Be notified when participating or @mentioned.": "���@��.",
            "Be notified of all conversations.": "@	���.",
            "Never be notified.": "�e�U�.",

            "commit": "!Ф",
            "commits": "!Ф",
            "branch": "/",
            "branches": "/",
            "release": "!�",
            "releases": "!�",
            "contributor": "*!.",
            "contributors": "*!.",
            "Copy to clipboard": "60j",
            "Copied!": "6�!",

            "Your recently pushed branches:": "� Ѩ�/:",
            "(less than a minute ago)": "0 �M",
            "Compare & pull request": "ԃ & ���B",

            "New pull request": "�w���B",
            "Create new file": "����",
            "Upload files": "
 ��",
            "Find file": "�~��",
            "Copy path": "6�",
            "Clone or download": "K�}",
            "Download ZIP": "} ZIP",
            "History": "��U",

            "Use SSH": "( SSH",
            "Use HTTPS": "( HTTPS",
            "Open in Desktop": "�LbHS ",

            "Clone with SSH": "� SSH K�",
            "Clone with HTTPS": "� HTTPS K�",
            "Use an SSH key and passphrase from account.": "( SSH ƥ����",
            "Use Git or checkout with SVN using the web URL.": "( git  svn ���ӓ",

            "Branch:": "/:",
            "Switch branches/tags": "	�/~",
            "Branches": "/",
            "Tags": "~",
            "Nothing to show": "��",

            "File uploading is now available": "�(��
 ���",
            "You can now drag and drop files into your repositories.": "���������0�ӓLb�L
 ",
            "Learn more": "���",
            "Dismiss": "�S�",

            // s�ub
            "Watchers": "s�",

            // �^ub
            "Stargazers": "�^��",
            "All": "h�",
            "You know": "�s�",

            // issues ub
            "opened this": "S �*",
            "Issue": "�",
            "added a commit that closed this issue": "(Ф�s��*�",
            "closed this in": "s�",
            "added the": "���",
            "added": "��",
            "and removed": "v�d�",
            "label": "~",
            "labels": "~",
            "self-assigned this": "������",
            "edited": "��",
            "added this to the": "��0",
            "milestone": "��",
            "closed this": "s�",
            "reopened this": "ͰS �",
            "This was referenced": "�/(",

            "No description provided.": "�	wS��",
            "Add your reaction": "����h�",
            "Pick your reaction": "	騄h�",
            "Leave a comment": "�hĺ",
            "Milestone": "��",
            "Unsubscribe": "ֈ�",
            "Attach files by dragging & dropping,": "����D�",
            "selecting them": "	��",
            ", or pasting from the clipboard.": "6�4��",
            "Styling with Markdown is supported": "/ Markdown ��",
            "Close issue": "s��",
            "Comment": "Ф",

            "Filters": "[	",
            "Open issues and pull requests": " >�����B",
            "Your issues": "�����",
            "Your pull requests": "�����B",
            "Everything assigned to you": "�Us���",
            "Everything mentioning you": "�ʨ�",
            "View advanced search syntax": "�ا"��",

            "Labels": "~",
            "None yet": "��",
            "Milestones": "��",
            "No milestone": "���",
            "Author": "\",
            "Assignee": "��",
            "Assignees": "��",
            "No one": "� - ",
            "assign yourself": " ���",
            "No one assigned": "��",
            "Sort": "��",

            "Filter by author": "[	(7",
            "Filter users": "[	(7",
            "Filter by label": "[	~",
            "Filter labels": "[	~",
            "Unlabeled": "�~",
            "Filter by milestone": "[	��",
            "Filter milestones": "[	��",
            "Issues with no milestone": "���",
            "Filter by whos assigned": "[	��",
            "Assigned to nobody": "���",
            "Sort by": "��",
            "Newest": " ��",
            "Oldest": " �",
            "Most commented": " ĺ",
            "Least commented": " ĺ",
            "Recently updated": " ���",
            "Least recently updated": " ���",
            "View all issues in this milestone": "��*���@	�",

            // New collaborator ub
            "New collaborator": "��\",
            "Collaborators": "\",
            "Push access to the repository": "SMӓ��CP",
            "This repository doesnt have any collaborators yet. Use the form below to add a collaborator.": "SMӓ�	\���(b�eF��\",
            "Search by username, full name or email address": ""(7, h, ��0@",
            "Add collaborator": "��\",

            // Upload files ub
            "Drag files here to add them to your repository": "������0SMӓ",
            "Drag additional files here to add them to your repository": "��vև���0SMӓ",
            "Drop to upload your files": "��
 ����",
            "Or": "",
            "choose your files": "	��",
            "Yowza, thats a big file. Try again with a file smaller than 25MB.": "�*��H'���U�����25MB",
            "Yowza, thats a lot of files. Try again with fewer than 100 files.": "�*��H�� !���100*",
            "This file is empty.": "�*��/z�",
            "Something went really wrong, and we cant process that file.": "G0����*��",
            "Uploading": "��
 -",
            "of": "",
            "files": "",
            "Commit changes": "Ф��",
            "Add files via upload": "�����
 ",
            "Optional extended description": "�	���",
            "Add an optional extended description&": "����... (�	)",
            "Commit directly to the": "Ф0",
            "Create a": "�",
            "new branch": "�/",
            "for this commit and start a pull request.": ":�*Фv�w *���B",
            "Learn more about pull requests.": "������B",

            // Find file ub
            "Youve activated the": "���;",
            "file finder": "��"!",
            ". Start typing to filter the file list. Use": "�es.��~����(",
            "and": "�",
            "to navigate,": "	��",
            "to view files,": "���",
            "to exit.": "��",

            // ���B�o�:
            "Your recently pushed branches:": "` Ѩ�/:",
            "Compare & pull request": "ԃ & ���B",

            // Pull Requests ub
            "There arent any open pull requests.": "�����B",
            "There arent any open issues.": "�� >��",
            "Use the links above to find what youre looking for, or try": "(
b���e~0��~��",
            "a new search query": "��"��",
            ". The Filters menu is also super helpful for quickly finding issues most relevant to you.": ""_/�~0� �s����	.��",

            "Conversation": "�",
            "Files changed": "�9���",
            "commented": "ĺ",
            "merged commit": "�vФ",
            "into": "0",
            "from": "e�",

            "Revert": "؟",

            "Avoid bugs by automatically running your tests.": "���K�eMBUG",
            "Continuous integration can help catch bugs by running your tests automatically.": "�������L��K�	��U��",
            "Merge your code with confidence using one of our continuous integration providers.": "v���(��������F",

            "Add more commits by pushing to the": "���e�",
            "branch on": "/�Ф�0",

            "This branch has no conflicts with the base branch": "�/base/�	��",
            "Merging can be performed automatically.": "���0gLv",
            "You can also": "�_��(",
            "open this in GitHub Desktop": "GitHubLbH,",
            "or view": "S �",
            "command line instructions": "}�L�",

            //// ��Ф���B
            "Open a pull request": "�� *���B",
            "Create a new pull request by comparing changes across two branches. If you need to, you can also": "�ԃ$*/��9e� *����B�� ����",
            "Able to merge.": "�v",
            "These branches can be automatically merged.": "�/��v",
            "file changed": "*����",
            "files changed": "*����",
            "commit comment": "!Ф",
            "commit comments": "!Ф",
            "No commit comments for this range": "�����	Ф��",

            "Comparing changes": "ԃ��",
            "Choose two branches to see whats changed or to start a new pull request. If you need to, you can also": "	�$*/���H9��w *����B��` �`_��",
            "base fork:": "�>:",
            "There isnt anything to compare.": "�	�U�ԃ",
            "is up to date with all commits from": "�/ �Ф�",
            ". Try": "�",
            "switching the base": "b�@�",
            "for your comparison.": "e�Lԃ",

            // projects ub
            "This repository doesn't have any projects yet": "�ӓ�M�	�Uy�",
            "Create a project": "� *y�",

            // wiki ub
            "Wikis provide a place in your repository to lay out the roadmap of your project, show the current status, and document software better, together.": "wiki :��ӓЛ� *�}��cD�",
            "Create the first page": "�, *ub",

            "Create new page": "��ub",
            "Write": "�",
            "Preview": "��",
            "Edit mode:": "�!:",
            "Edit Message": "Ф�o",
            "Save Page": "�Xub",

            // settings ub
            "Webhooks & services": "Web�P & �",
            "Deploy keys": "�rƥ",

            "Options": "�,	y",
            "Repository name": "ӓ",
            "Rename": "�}",
            "Features": "y'",
            "GitHub Wikis is a simple way to let others contribute content. Any GitHub user can create and edit pages to use for documentation, examples, support, or anything you wish.": "GitHub Wikis / *�U��թ+�!.��GitHub ��U(7������ub-(��c:�/�U��",
            "Restrict editing to collaborators only": "�P6�	\��",
            "Public wikis will still be readable by everyone.": "lq wikis �6�0'����'",
            "GitHub Issues adds lightweight issue tracking tightly integrated with your repository. Add issues to milestones, label issues, and close & reference issues from commit messages.": "GitHub ��X����{ϧ��*'����������~�v���Ф�o",

            "Merge button": "v	�",
            "When merging pull requests, you can allow merge commits, squashing, or both.": "Sv���B����A�vФ�)",
            "Allow merge commits": "A�vФ",
            "Add all commits from the head branch to the base branch with a merge commit.": "�head/�@	ФvФ0base/",
            "Allow squash merging": "A��)v",
            "Combine all commits from the head branch into a single commit in the base branch.": "�head/�@	Ф�)Ф0base/",
            "You must select at least one option": "���	� *	y",

            "GitHub Pages": "GitHub y�:ub",
            "Your site is published at": "��:0@::",
            "Your site is ready to be published at": "��:0@::",
            "is designed to host your personal, organization, or project pages from a GitHub repository.": ":�����ӓy�ЛYwebub",
            "Source": "�",
            "Your GitHub Pages site is currently being built from the": "`� GitHub Pages Q��Mc(��(",
            "branch.": "/",
            "Select source": "	�",
            "Use the": "(",
            "branch for GitHub Pages.": "/\: GitHub Pages",
            "Disable GitHub Pages.": "�( GitHub Pages",
            "Custom domain": "�I�",
            "Custom domains allow you to serve your site from a domain other than": "�I�_�`(v����",
            "Update your site": "����ٹ",
            "To update your site, push your HTML or": "����ٹ����� html (",
            "updates to your": "��0",
            "branch. Read the": "/����",
            "Pages help article": ":ub.�",
            "for more information.": "����o",
            "Overwrite site": "�ְ	ٹ",
            "Replace your existing site by using our automatic page generator. Author your content in our Markdown editor, select a theme, then publish.": "�(��ubh�b�	�Q����(� Markdown �h	� *;�6�",
            "Launch automatic page generator": "/��h",
            "Enforce HTTPS": ":6 HTTPS",
            " Unavailable for your site because you have a custom domain configured (": "- ��:��Q� /�:�Mn� *�I� (",
            "HTTPS provides a layer of encryption that prevents others from snooping on or tampering with traffic to your site.": "HTTPS Л� B��2bֺw��9��0��Q�",
            "When HTTPS is enforced, your site will only be served over HTTPS.": "S /:6 HTTPS ��Q���� HTTPS ��",

            "Danger Zone": "qi:",
            "Make this repository private": "�ӓ�:�	ӓ",
            "Public forks cant be made private. Please": ">��ӓ��l:�	�",
            "duplicate the repository": "6 ��ӓ",
            "Make private": "l:�	",
            "Please": "�",
            "upgrade your plan": "�����	ӓ�",
            "to make this repository private.": "��*ӓl:�	",
            "Transfer ownership": "l�@	C",
            "Transfer": "l�",
            "Transfer this repository to another user or to an organization where you have admin rights.": "dX��l�0v�(7��(�̨w	�XCP",
            "Delete this repository": " ddӓ",
            "Once you delete a repository, there is no going back. Please be certain.": " � d��ӓ��~���	",

            "Default branch": "ؤ/",
            "The default branch is considered the base branch in your repository, against which all pull requests and code commits are automatically made, unless you specify a different branch.": "ؤ/��:/�0/(��D���@	���B���Ф/��L�d^�� *�/",
            "Update": "��",
            "Switch default branch": "	�ؤ/",
            "Filter branches": ""/",
            "Protected branches": "�ݤ�/",
            "Protect branches to disable force pushing, prevent branches from being deleted, and optionally require status checks before merging. New to protected branches?": "�ݤ/�(:6�M d/:�v�	�BM�������ݤ�/:�",
            "Learn more.": "���o",
            "No protected branches yet.": "���ݤ/",

            "Are you ABSOLUTELY sure?": "�n� ��ʯ�",
            "Unexpected bad things will happen if you dont read this!": "������:�o",
            "This action": "��\/",
            "CANNOT": "��",
            "be undone. This will permanently delete the": "�8E d",
            "repository, wiki, issues, and comments, and remove all collaborator associations.": "ӓwikiФ��v�d@	\",
            "Please type in the name of the repository to confirm.": "���e�ӓ�n� d�",
            "I understand the consequences, delete this repository": "n� ��ʯ� d�",

            // Compare changes ub
            "Compare changes": "��ԃ",
            "Compare changes across branches, commits, tags, and more below. If you need to, you can also": "ԃ�/Ф~�������� �_��",
            "compare across forks": "ԃ>���ӓ",
            "base:": "�@�:",
            "compare:": "ԃ�:",
            "Create pull request": "����B",
            "Choose different branches or forks above to discuss and review changes.": "	��/>e�����",
            "Compare and review just about anything": "ԃ����U��",
            "Branches, tags, commit ranges, and time ranges. In the same repository and across forks.": "/~Ф����( ӓ�>�ӓ",
            "Example comparisons": "ԃ�P",

            // ��zӓ
            "Quick setup": "���",
            " if youve done this kind of thing before": "- ����MZ��7��",
            "Set up in Desktop": "��0Lb",
            "We recommend every repository include a": "�P�*ӓ��",
            ", and": "�",
            "&or create a new repository on the command line": "&(}�L
� *��ӓ",
            "&or push an existing repository from the command line": "&�}�L-��	�ӓ",
            "&or import code from another repository": "&�� *ӓ��e�",
            "You can initialize this repository with code from a Subversion, Mercurial, or TFS project.": "����dӓ� * SubversionMercurial  TFS y�",
            "Import code": "�e�",

            // commits ub
            "committed": "Ф�",
            "Merge pull request": "v���B",
            "Confirm merge": "n�v",
            "Close pull request": "s����B",

            "Copy the full SHA": "6�t� SHA",
            "Browse the repository at this point in the history": "O��6����ӓ��",

            "Newer": "��",
            "Older": "�",

            // branches ub
            "Overview": "��",
            "Yours": "��",
            "Active": ";Ä",
            "Stale": "H�",
            "All branches": "@	/",
            "Search branches&": ""/&",

            "Your branches": "��/",
            "You havent pushed any branches to this repository.": "��	��U/0�ӓ",
            "Active branches": ";Ä/",
            "There arent any active branches.": "�	�U;Ä/",
            "Stale branches": "H�/",
            "There arent any stale branches.": "�	�UH�/",
            "View more active branches": "��;Ä/",
            "View more stale branches": "��H�/",
            "Compare": "ԃ",
            "Change default branch": "�9ؤ/",

            // Releases ub
            "Releases": "�",
            "Pre-release": "��",
            "Downloads": "}",
            "Notes": "�",
            "There arent any releases here": "�	�U���",
            "Create a new release": "� *�",
            "Releases are powered by": "�/�(ӓ-�",
            "tagging specific points of history": "y���H,",
            "in a repository. Theyre great for marking release points like": "(���H,{<",

            "Latest release": " ��",
            "Read release notes": "���",
            "released this": "��",
            "tagged this": "�",

            "Draft a new release": "wI�H,�",
            "Add release notes": "����",
            "Edit release notes": "���",
            "(No release notes)": "(�	��)",
            "Release notes": "��",

            "Edit tag": "�9~",
            "Edit release": "�9�",
            "Delete": " d",
            "Are you sure?": "�n� ��ʯ�",
            "This will delete the information for this tag.": " d�~�@	�o",
            "Delete this tag": " dd~",
            "Your tag was removed": "~ d�",

            "Existing tag": "�X(�~",
            "Markdown supported": "Markdown ��/",
            "Attach binaries by dropping them here or": "����0�e��D�",
            "This is a pre-release": "�/ *��H,",
            "Well point out that this release is identified as non-production ready.": "���H,:*c�",
            "Update release": "���",
            "Publish release": "�H,",
            "Save draft": "�XI?",
            "Saved!": "��X",
            "Saving draft failed. Try again?": "�X1%�� !",

            // �hub
            "Contributors": "!.",
            "Traffic": "A�",
            "Commits": "Ф",
            "Code frequency": "��",
            "Punch card": "�;",
            "Network": "Q�",
            "Members": "X",

            "Contributions to master, excluding merge commits": "�;/�!.�vФ",
            "Contributions:": "!.:",
            "Filter contributions": "[	!.",
            "Additions": "��p�",
            "Deletions": " dp�",

        },
        "regexp": [ // c��
            [/HTTPS\s+(recommended)/, "HTTPS (�P)"],
            [/Save (.+?) to your computer and use it in GitHub Desktop./, "( GitHub LbH�X $1 0��5"],
            [/([\d,]+) Open/, "$1 * >�"],
            [/([\d,]+) Closed/, "$1 *s�"],
            [/View all issues opened by (.+)/, "�@	 $1 ��"],
            [/Welcome to the ([^ ]+) wiki!/, ""ο� $1 � wiki"],
            [/([\d,]+) participants?/, "$1 �"],
            [/Commits on (.+)/, "Ф� $1"],
            // bug [/from (.+)/, "� $1"],
            [/wants to merge ([\d,]+) commits? into/, " �v $1 !Ф0"],
            [/([\d,]+) commits?/, "$1 !Ф"],
            [/to ([^\n]+)[\n\s]+since this release/, "0 $1 /(d�-"],
            [/� ([\d,]+) comments?/, "$1 !Ф"]
        ],
    },

    "homepage": { // *{U�u
        "static": { // Y��
            "Pick a username": "	� *(7",
            "Your email address": "����0@",
            "Create a password": "� *�",
            "Sign up for GitHub": "� GitHub",

            "Use at least one letter, one numeral, and seven characters.": "� �W͌pW�� 7 M�
W&2",
            "By clicking \"Sign up for GitHub\", you agree to our": "�� � GitHubh:��",
            "terms of service": "�a>",
            "and": "�",
            "privacy policy": "��?Va>",
            "We'll occasionally send you account related emails.": "�v���7�s�5P��",

            "How people build software": "��U��o�",
            "Millions of developers use GitHub to build personal projects, support their businesses, and work together on open source technologies.": "p�~�� ѺX( GitHub ��*�y�/��q( >��/",

            "Introducing unlimited": "e�P6�",
            "private repositories": "��ӓ",
            "All of our paid plans on GitHub.com now include unlimited private repositories.": "@	(� GitHub.com 
��9(7�Л�P6���ӓ",
            "Sign up": "�",
            "to get started or": " �(",
            "read more about this change on our blog": "���o(�Z�
",

            "Welcome home, developers": ""��e ��",
            "GitHub fosters a fast, flexible, and collaborative development process that lets you work on your own or with others.": "GitHub Л� *�u;�O\ �������ֺ\",

            "For everything you build": ":�S ",
            "Host and manage your code on GitHub. You can keep your work private or share it with the world.": ";:�����( GitHub 
��动��\��L�",
            "A better way to work": " *�}��\�",
            "From hobbyists to professionals, GitHub helps developers simplify the way they build software.": "�Y1}0��GitHub .� ѺX�����o�",
            "Millions of projects": "p�~��y�",
            "GitHub is home to millions of open source projects. Try one out or get inspired to create your own.": "GitHub /p~ �y�� *��ue ���y�",
            "One platform, from start to finish": " *s�����",
            "With hundreds of integrations, GitHub is flexible enough to be at the center of your development process.": "~
C��GitHub /�u;��(���U��-�",

            "Who uses GitHub?": "(( GitHub ?",
            "Individuals": "*�",
            "Use GitHub to create a personal project, whether you want to experiment with a new programming language or host your lifes work.": "( GitHub e� **�y����� *��� ;:(�;��\",
            "Communities": ">:",
            "GitHub hosts one of the largest collections of open source software. Create, manage, and work on some of todays most influential technologies.": "GitHub ;:/ '� >�o���K ����( �S� wq͛��/�\",
            "Businesses": "",
            "Businesses of all sizes use GitHub to support their development process and securely build software.": "��!�(� GitHub /v�U�-�h0��o�",

            "GitHub is proud to host projects and organizations like": "GitHub /�j0>�y����",
            "Public projects are always free. Work together across unlimited private repositories for $7 / month.": "lqy�/M9���y� �/� 7 �C *�9(",
        },
        "regexp": [ // c��
        ],
    },

    "session-authentication": { // {Uu
        "static": { // Y��
            "Sign in to GitHub": "{U GitHub 7",
            "Username or email address": "(7/��",
            "Password": "�",
            "Forgot password?": "ذ�",
            "Sign in": "{U",
            "New to GitHub?": ", !e GitHub?",
            "Create an account": "�1�*7'",
        },
        "regexp": [ // c��
        ],
    },

    "signup": { // �u
        "static": { // Y��
            "Join GitHub": "�e GitHub",
            "The best way to design, build, and ship software.": " ��e�����X�o�",

            "Step 1:": ", e:",
            "Set up a personal account": "��*�&7",
            "Step 2:": ",�e:",
            "Choose your plan": "	騄�H",
            "Step 3:": ",	e:",
            "Go to your dashboard": "�0���u",

            // Step 1:
            "Create your personal account": "���*�&7",
            "Username": "(7 (_/�*��u���0@)",
            "This will be your username  you can enter your organizations username next.": "�/��(7 - _��/���l���",
            "Email Address": "Email 0@",
            "You will occasionally receive account related emails. We promise not to share your email with anyone.": "宱(��6�s�����l ��5P����U�",
            "Password": "�",
            "Use at least one lowercase letter, one numeral, and seven characters.": "� �W͌pW�� 7 M�
W&2",
            "By clicking on \"Create an account\" below, you are agreeing to the": "��b��&7h:��",
            "Terms of Service": "�a>",
            "and the": "�",
            "Privacy Policy": "��?V",
            "Create an account": "�&7",

            "Youll love GitHub": "�1
 GitHub",
            "Unlimited": "�P�",
            "collaborators": "\",
            "public repositories": "lqӓ",
            "Great communication": "o}��",
            "Friction-less development": "�i� �",
            "Open source community": " �>:",

            // Step 2:
            "Welcome to GitHub": ""�e0 GitHub",
            "Youve taken your first step into a larger world,": "������, e�e0�'�L",
            "Choose your personal plan": "	騄*��H",
            "Unlimited public repositories for free.": "�P�lqӓM9(",
            "Unlimited private repositories": "�P���ӓ",
            "for": " ",
            "$7/month.": "$7/",
            "�46.06/month.": "�46.06/.",
            "(view in CNY)": "(>:��<)",
            "(view in USD)": "(>:�C�<)",
            "Dont worry, you can cancel or upgrade at any time.": "+��`���G�ֈ�*�H",
            "Charges to your account will be made in ": "G����ц...",
            "Secure": "�h",
            "Enter your billing details": "�e��U�",
            "Pay with": "/ع",
            "Credit card": "�(a",
            "PayPal account": "PayPal &7",
            "Credit card number": "�(a�",
            "Accepted cards": "/�a",
            "Help me set up an organization next": ".�� *��",
            "Organizations are separate from personal accounts and are best suited for businesses who need to manage permissions for many employees.": "��/�ˎ*�&7/  ��CP��X�",
            "Learn more about organizations.": "��s��Ǆ�o",
            "Finish sign up": "��",

            "Both plans include:": "�$͹H�",
            "Collaborative code review": "O\���",
            "Issue tracking": "��*",
            "Unlimited public repositories": "�P6�lqӓ",
            "Join any organization": "�e�U��",
        },
        "regexp": [ // c��
        ],
    },

    "notifications": { // �ub
        "static": { // Y��
            "Mark all as read": "h�:��",
            "Are you sure?": "�n�",
            "Are you sure you want to mark all unread notifications as read?": "`n��@	�*���:��",
            "Mark all notifications as read": "h�:��",

            "Notifications": "�",
            "Watching": "s�ӓ",
            "Unread": "*�",
            "Participating": "�ݘ",
            "All notifications": "@	�",

            "No new notifications.": "�	���",
            "Depending on": "9n",
            "your notification settings": "���n",
            ", youll see updates here for your conversations in watched repositories.": "�0�s�ӓ����o",
        },
        "regexp": [ // c��
        ],
    },

    "watching": { // s�ӓub
        "static": { // Y��
            "Notifications": "�",
            "Watching": "s�ӓ",

            "Watched repositories": "s�ӓ",
            "Sorted by most recently watched.": "	 �s蒏",
            "Unwatch all": "ֈ@	s�",
            "Notification settings": "�n",
            "You can change how you receive notifications from your account settings.": "����9�6儹",
            "Change notification settings": "�9�n",
        },
        "regexp": [ // c��
        ],
    },

    "stars": { // �^ub
        "static": { // Y��
            "All stars": "@	ӓ",
            "Your repositories": "��ӓ",
            "Others' repositories": "v�ӓ",

            "Filter by languages": "[	� ",
            "Jump to a friend": "�}�ˣ",
        },
        "regexp": [ // c��
        ],
    },

    "trending": { // ��ub
        "static": { // Y��
            "Trending in open source": " ���",
            "See what the GitHub community is most excited about today.": " GitHub >:�) �s�y�",
            "See what the GitHub community is most excited about this week.": " GitHub >:,h �s�y�",
            "See what the GitHub community is most excited about this month.": " GitHub >:, �s�y�",

            "Trending developers": " ���",
            "These are the organizations and developers building the hot tools today.": "�/�)���y��ǌ ѺX",
            "These are the organizations and developers building the hot tools this week.": "�/,h���y��ǌ ѺX",
            "These are the organizations and developers building the hot tools this month.": "�/,���y��ǌ ѺX",

            "Repositories": "ӓ",
            "Developers": " �",

            "Trending:": "��:",
            "Adjust time span": "t����",
            "today": "�)",
            "this week": ",h",
            "this month": ",",

            "All languages": "@	� ",
            "Unknown languages": "*�� ",

            "Other:": "v�:",
            "Languages": "� ",
            "Other Languages": "v�� ",
            "Filter Languages": "[	� ",
        },
        "regexp": [ // c��
            [/([\d,]+) stars today([^B]+)[\w ]+/, "�) $1 ^$2�"],
            [/([\d,]+) stars this week([^B]+)[\w ]+/, ",h $1 ^$2�"],
            [/([\d,]+) stars this month([^B]+)[\w ]+/, ", $1 ^$2�"],
        ],
    },

    "showcases": { // U:ub
        "static": { // Y��
            "Open source showcases": " �U:",
            "Browse popular repositories based on the topic that interests you most.": "O���ӓ��` t��ݘ",
            "Search showcases": ""U:",
        },
    },


    "issues": { // �ub
        "static": { // Y��
            "Created": "��",
            "Assigned": "�M",
            "Mentioned": "�0�",

            "Visibility": "��'",
            "Repository visibility": "ӓ��'",
            "Private repositories only": "�	�	ӓ",
            "Public repositories only": "�	lq�",

            "Organization": "��",
            "Filter by organization or owner": "���@	[	",
            "Filter organizations": "[	��",

            "Sort": "��",
            "Sort by": "���",
            "Newest": " ��",
            "Oldest": " �",
            "Most commented": " ĺ",
            "Least commented": " ĺ",
            "Recently updated": " ���",
            "Least recently updated": " ���",
            "Most reactions": " ޔ",

            "No results matched your search.": "�	&��"Ӝ",
            "Use the links above to find what youre looking for, or try": "(
b���~0��~����",
            "a new search query": "��"��",
            ". The Filters menu is also super helpful for quickly finding issues most relevant to you.": "���U_/�~0� �s����	.��",
            "ProTip!": "�:",
            "Updated in the last three days": "��� 	)",
        },
        "regexp": [ // c��
            [/(\d+) Open/, "$1 *"],
            [/(\d+) Closed/, "$1 �"],
        ],
    },


    "search": { // "ub
        "static": { // Y��
            "Search more than": "��	��",
            "repositories": "�ӓ��"",

            "Repositories": "ӓ",
            "Code": "�",
            "Users": "(7",

            "Languages": "� ",

            "Advanced search": "ا"",
            "Cheat sheet": ""��",
            "You could try an": "���� �",
            "advanced search": "ا"",

            "Sort:": "��:",
            "Sort options": "��	y",
            "Best match": " s9M",
            "Most stars": " ^",
            "Fewest stars": " ^",
            "Most forks": " >",
            "Fewest forks": " >",
            "Recently updated": " ���",
            "Least recently updated": " ���",

            // ا"
            "Advanced options": "ا	y",
            "From these owners": "�\",
            "In these repositories": "�ӓ",
            "Created on the dates": "��",
            "Written in this language": "(� ",
            "Any Language": "�U� ",
            "Popular": "AL�",
            "Everything else": "v�� ",

            "Repositories options": "ӓ	y",
            "With this many stars": "��^p",
            "With this many forks": "�>p",
            "Of this size": "ӓ'",
            "Pushed to": "��",
            "Return repositories": ""Ӝ",
            "not": "",
            "and": "�",
            "only": "�",
            "including forks.": "�>�ӓ",

            "Code options": "�	y",
            "With this extension": "�� ",
            "Of this file size": "��'",
            "In this path": "���",
            "Return code from forked repositories": ""Ӝ�>�ӓ",

            "Issues options": "�	y",
            "In the state": "",
            "With this many comments": "ĺp�",
            "With the labels": "�~",
            "Opened by the author": "��",
            "Mentioning the users": "�0",
            "Assigned to the users": "M�",
            "Updated before the date": "���",

            "Users options": "(7	y",
            "With this full name": "(7h�",
            "From this location": "e���",
            "With this many followers": "	�",
            "With this many public repositories": "	lqӓ",
            "Working in this language": "��H� ",

        },
        "regexp": [ // c��
            [/Weve found ([\d,]+) repository results/, "�:�~0 $1 *�sӜ"],
            [/We couldnt find any repositories matching '(.+)'/, "�	~0�U '$1' �s�Ӝ"],
        ],
    },


    "gist": { // �G�ub
        "static": { // Y��
            "Search&": ""�G�&",
            "All gists": "@	G�",
            "New gist": "��G�",
            "Your gists": "��G�",
            "Starred gists": "�^G�",
            "Your GitHub profile": "�n",

            "View profile and more": "���o",
            "See all of your gists": "���@	G�",
            "Instantly share code, notes, and snippets.": "s������G���u",
            "Gist description&": "G���",

            "Filename including extension&": "�� (�iU)",
            "Indent mode": ")�!",
            "Spaces": "z<",
            "Tabs": "TAB",
            "Indent size": ")�'",
            "Line wrap mode": "bL!",
            "No wrap": "�bL",
            "Soft wrap": "obL",
            "Add file": "����",
            "Create secret gist": "��	G�",
            "Secret gists are hidden from search engines but visible to anyone you give the URL.": "�	G�"�/0�F/������ url ���",
            "Create public gist": "�lqG�",

            // All gists ub
            "Sort:": "��:",
            "Sort options": "��	y",
            "Recently created": " ���",
            "Least recently created": " ���",
            "Recently updated": " ����",
            "Least recently updated": " ����",
            "Filter:": "[	:",
            "Filter options": "[		y",
            "Public & Secret": "lq & �	",
            "Public only": "�lq",
            "Secret only": "��	",
            "forked from": ">�",
            "Created": "��",
            "View": "�",
            "Newer": "��",
            "Older": "�",

            // View � ub
            "Edit": "�",
            "Delete": " d",
            "Star": "�^",
            "Unstar": "ֈ�^",
            "User actions": "(7�\",
            "Report abuse": ">��(7",

            "Code": "�",
            "Revisions": "�",
            "Stars": "�^",
            "Forks": ">",

            // �ub
            "What would you like to do?": "��Z�H",
            "Embed this gist in your website.": "Embed �Le0��Qu-",
            "Copy sharable URL for this gist.": "6 URL q��*G�",
            "Clone with Git or checkout with SVN using the repository's web address.": "Git K� SVN ���ӓ@(� web 0@",
            "Clone with an SSH key and passphrase from your GitHub settings.": "( SSH ƥK�",
            "Learn more about clone URLs": "��K���",

            "Copy to clipboard": "60j",
            "Copied!": "6�!",
            "Download ZIP": "} ZIP",
            "Permalink": "8E��",
            "Raw": "�",

            // �ub
            "Unified": "O",
            "Split": "O",
            "created": "�",
            "this gist": "�G��",

            // ��ub
            "Editing": "�",
            "Make secret": "l:�	",
            "Cancel": "ֈ",
            "Update public gist": "��G�",

            // �^ub
            "Starred": "^�",
            "You dont have any starred gists yet.": "�ء	^��UG�",
        },
        "regexp": [ // c��
            [/View ([^ ]+) on GitHub/, "� $1 � GitHub"],
            [/(\d+) files?/, "$1 ��"],
            [/(\d+) forks?/, "$1 >"],
            [/(\d+) comments?/, "$1 ĺ"],
            [/(\d+) stars?/, "$1 ^"],
            [/Save (.+?) to your computer and use it in GitHub Desktop./, "( GitHub LbH�X $1 0��5"],
        ],
    },

    "oauth": { // �(�C
        "static": { // Y��
            "Authorize application": "�(�C",
            "by": "�",
            "would like permission to access your account": "�7",
            "Review permissions": "�CP",
            "Public data only": "�lqpn",
            "Limited access to your public data": "�P�lqpn",
            "This application will be able to identify you and read public information.": "d�(���+������֨�lq�o",
            "Learn more": "�",

            "Visit applications website": "��(�Q",
            "Learn more about OAuth": "���C�o",
        },
        "regexp": [ // c��
        ],
    },
};


// lq(���
I18N.zh.pulls = I18N.zh.issues;
