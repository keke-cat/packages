// ==UserScript==
// @name         （4.24更新免广告最新版本）全网 VIP 视频在线解析，接口每日更新,一键免费看爱奇艺/优酷/搜狐/腾讯/芒果/AB站等Vip影视接口多
// @namespace    http://asvideo.top/
// @version      2.1
// @description  优酷 爱奇艺 腾讯 芒果 AB站 
// @author       爱尚解析
// @license      MIT
// @match        *://v.youku.com/v_show/*
// @match        *://*.iqiyi.com/v_*
// @match        *://*.iqiyi.com/dianying/*
// @match        *://*.le.com/ptv/vplay/*
// @match        *://v.qq.com/x/cover/*
// @match        *://v.qq.com/x/page/*
// @match        *://*.tudou.com/listplay/*
// @match        *://*.tudou.com/albumplay/*
// @match        *://*.tudou.com/programs/view/*
// @match        *://*.mgtv.com/b/*
// @match        *://*.sohu.com/*
// @match        *://item.taobao.com/*
// @match        *://detail.tmall.com/*
// @match        *://*.acfun.cn/v/*
// @match        *://*.bilibili.com/video/*
// @match        *://*.bilibili.com/anime/*
// @match        *://v.pptv.com/show/*
// @match        *://v.yinyuetai.com/video/*
// @match        *://v.yinyuetai.com/playlist/*
// @match        *://*.wasu.cn/Play/show/*
// @require      http://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @run-at       document-end
// @grant        unsafeWindow
// ==/UserScript==

(function() {
    'use strict';
    var curPlaySite = '';
    var curWords = '';
    var videoSite = window.location.href;
    var reYk = /youku/i;
    var reAqy = /iqiyi/i;
    var reLS = /le/i;
    var reTX = /qq/i;
    var reTD = /tudou/i;
    var reMG = /mgtv/i;
    var reSH = /sohu/i;
    var reAF = /acfun/i;
    var reBL = /bilibili/i;
    var reYJ = /1905/i;
    var rePP = /pptv/i;
    var reYYT = /yinyuetai/i;
    var vipBtn = '<a id="asvideoBtn" style="cursor:pointer;text-decoration:none;color:red;padding:0 5px;border:1px solid red;">一键vip解析</a>';
    
  // 优酷
    if(reYk.test(videoSite)){
        vipBtn
        var youkuTitle = $('#headq');
        if(youkuTitle.length !== 0){
        	youkuTitle.after(vipBtn);
	        $('#asvideoBtn').css({'font-size':'17px','display':'inline-block','height':'22px','line-height':'22px','margin':'0 5px','vertical-align':'bottom'});
	       
	        if($('.tvinfo').length !== 0){
	        	curWords = $('.tvinfo').find('h3').eq(0).text();
	        }else{
	        	curWords = $('.title').attr('title');
	        }
	        
        }else{
        	$('.tags').after(vipBtn);
        	$('#asvideoBtn').css({'font-size':'17px','display':'inline-block','height':'22px','line-height':'22px','margin':'0 5px','vertical-align':'bottom'});
	        
	       	if($('.tvinfo').length !== 0){
	        	curWords = $('.tvinfo').find('h3').eq(0).text();
	        }else{
	        	curWords = $('.title').attr('title');
	        }
	       
        }
    }
    // 爱奇艺
    if(reAqy.test(videoSite)){
        var iqiyiTitle = $('#widget-videotitle');
        iqiyiTitle.parent('.mod-play-tit').append(vipBtn);
        $('#asvideoBtn').css({'font-size':'17px','display':'inline-block','height':'24px','line-height':'24px','margin':'0 5px'});
       
        if($('#drama-series-title').length !== 0){
        	curWords = $('#drama-series-title').find('a').text();
        }else{
        	curWords = iqiyiTitle.text();
        }
        
    }
    // 乐视
    if(reLS.test(videoSite)){
        var lsTitle = $('.briefIntro_tit');
        lsTitle.after(vipBtn);
        lsTitle.css('float','left');
        $('#asvideoBtn').css({'font-size':'16px','display':'inline-block','height':'20px','line-height':'20px','margin':'0 5px'});
       
       	if($('.Info').find('.title').find('h3').length !== 0){
        	curWords = $('.Info').find('.title').find('h3').text();
        }else{
        	curWords = lsTitle.text();
        }
      
    }
    // 腾讯
    if(reTX.test(videoSite)){
        var qqTitle = $('.mod_intro').find('.video_title');
        qqTitle.eq(0).after(vipBtn);
        $('#asvideoBtn').css({'font-size':'24px','display':'inline-block','height':'36px','line-height':'36px','margin':'0 5px'});
        
        if($('.player_title').length !== 0 && $('.player_title').find('a').length === 0){
        	curWords = $('.player_title').text();
        }else{
        	curWords = $('._base_title').text();
        }
        if(curWords === ''){
        	curWords = $('.player_title').text();
        }
        
    }
    // 土豆
    if(reTD.test(videoSite)){
        var tdTitle = $('.td-playbase__title');
        tdTitle.parent('.fix').append(vipBtn);
        $('#asvideoBtn').css({'font-size':'18px','display':'inline-block','height':'22px','line-height':'22px','margin':'14px 5px 0'});
    }
    $(document).ready(function() {
      var str_host       = window.location.host;
      var str_host_name  = 'taobao';
      var str_goods_name = '';//$(document).attr('title');
      if(str_host.indexOf('taobao.com')==-1) str_host_name = 'tmall';
      if(str_host_name=='taobao'){
          str_goods_name = $('.tb-main-title').text();
      }else{
          str_goods_name = $('meta[name=keywords]').attr('content');
         
      }
      
      str_goods_name=$.trim(str_goods_name);

      var btn_quan_taobao = '<a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;margin-left:10px" href="http://52tbquan.top/index.php?r=searchlist&kwd='+ encodeURI(str_goods_name) +'" target="_blank">获取优惠券</a>';
      var btn_quan_tmall =   '<div class="tb-action" style="margin-top:0"><a style="display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: normal;height:26px;line-height:26px;width:156px;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;" href="http://52tbquan.top/index.php?r=searchlist&kwd='+ encodeURI(str_goods_name) +'">获取优惠券</a></div>';
      var faNode = document.querySelector("div#J_Title p.tb-subtitle, div.tb-detail-hd");
      if(str_host_name=='taobao'){
          $('.tb-action').append(btn_quan_taobao);
          $('.tb-action').append(btn_search_taobao);

      }else{
          $('.tb-sku').append(btn_quan_tmall);
          $('.tb-sku').append(btn_search_tmall);
      }
    });
    // 芒果
    if(reMG.test(videoSite)){
        var mgTitle = $('.v-panel-title');
        mgTitle.after(vipBtn);
        mgTitle.css({'float':'left','margin-right':'0'});
        $('#asvideoBtn').css({'font-size':'22px','display':'inline-block','height':'40px','line-height':'40px','margin':'0 5px'});
        
    	curWords = mgTitle.text();
        
    }
    
    // 搜狐
    if(reSH.test(videoSite)){
        var shTitle = $('.crumbs');
        shTitle.append(vipBtn);
        shTitle.find('h2').css({'float':'left'});
        $('#asvideoBtn').css({'font-weight':'bold','font-size':'16px','display':'inline-block','height':'36px','line-height':'36px','margin':'0 5px'});
        
        curWords = shTitle.find('h2').text();
       
    }
    // A站
    if(reAF.test(videoSite)){
        var acTitle = $('.head').find('.title');
        acTitle.append(vipBtn);
        $('#asvideoBtn').css({'font-weight':'bold','font-size':'16px','display':'inline-block','height':'20px','line-height':'20px','margin':'0 5px'});
    }
    // B站
    if(reBL.test(videoSite)){
        var biliTitle = $('.v-title').find('h1');
        biliTitle.after(vipBtn);
        biliTitle.css({'float':'left','margin-right':'0'});
        $('#asvideoBtn').css({'font-weight':'bold','font-size':'16px','display':'inline-block','height':'36px','line-height':'36px','margin':'0 5px'});
    }
    // pptv
    if(rePP.test(videoSite)){
        var pptvTitle = $('.hd-logo fl');
        pptvTitle.after(vipBtn);
        $('#asvideoBtn').css({'font-weight':'bold','font-size':'16px','display':'inline-block','height':'36px','line-height':'36px','margin':'0 5px'});
  
        curWords = pptvTitle.text();
       
    }
    // 音悦台
    if(reYYT.test(videoSite)){
        var yytTitle = $('.videoName');
        yytTitle.append(vipBtn);
        $('#asvideoBtn').css({'font-weight':'bold','font-size':'14px','display':'inline-block','height':'32px','line-height':'32px','margin':'0 5px'});
    }
    $('#asvideoBtn').on('click',function(){
        curPlaySite = window.location.href;
        window.location.href = 'http://asvideo.top/sousou.php?url=' + curPlaySite;
    });
})();